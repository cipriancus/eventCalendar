package wordGame;

public class help {
	public static String SearchBestWord(String tiles) {

		String litere = tiles;

		for (int i = 7; i > 0; i--) {
			// verificam daca se poate forma un cuvant cu literele ramase
			int j = i;
			WordChecker verificator = new WordChecker();
			boolean isWord;
			isWord = verificator.check_for_word(litere);
			if (isWord)
				return litere;
			while (j != 0)// permutam literele sa vedem daca exista cuvinte cu
							// "noul cuvant"
			{
				j--;
				permutation("", litere);
				isWord = verificator.check_for_word(litere);
				if (isWord)
					return litere;
			}
			// scoatem cate o litera
			if (i >= 2) {
				i--;
				litere = litere.substring(0, i) + litere.substring(i + 1);
				i++;
			}else
			{
				System.out.println("nu a gasit");
			}
		}
		return "";

	}

	private static void permutation(String prefix, String str) {
		int n = str.length();
		if (n != 0) {
			for (int i = 0; i < n; i++)
				permutation(prefix + str.charAt(i), str.substring(0, i) + str.substring(i + 1, n));
		}
	}

}
