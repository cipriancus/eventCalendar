package wordGame;

public class jocRun implements Runnable {

	int Index;
	String tiles;
	boolean lead = false;
	static boolean bull = false;

	public void run() {
		int k = 7,nrlit=0;;
		int stop = 0;
		String newLetters = "";
		String newWord = "";
		String Letters="";
		String toPrint;
		boolean toBeOrNotToBe;
		while (stop < 100) {
			nrlit=nrlit+k;
			Letters = takeOutTheWord(Letters, newWord);// eliminam cuvantul
															// din fostul sir de
															// litere
			newLetters = getKLetters(k);// preluam cele k litere necesare pentru
										// a reface box-ul de 7
			toPrint = "Threadul " + Index + " a ramas cu literele:" + Letters;
			System.out.println(toPrint);
			toPrint = "Threadul " + Index + " a primit cele" + k + " litere :" + newLetters;
			System.out.println(toPrint);

			Letters = Letters + newLetters;
			toPrint = "Threadul " + Index + " a primit literele:" + Letters;
			System.out.println(toPrint);
			newWord = helpMe(Letters);// sau il putem introduce noi
			toPrint = "Threadul " + Index + " a format automat cuvantul:" + newWord;
			System.out.println(toPrint);
			WordChecker verif = new WordChecker();
			toBeOrNotToBe=(verif.check_for_word(newWord));
			if (toBeOrNotToBe) { // daca este cuvant il contorizam
				stop = stop + newWord.length();
				k = newWord.length();
				System.out.println("este bun cuvantul : "+ newWord);
			} else {
				System.out.println("Wrong Word");
			}
		}
		toPrint = "Gata Threadul " + Index + " cu scorul:" + stop+"din un nr de litere de:"+nrlit;
		System.out.println(toPrint);

	}

	public jocRun(int stopValue, boolean islead) {
		Index = stopValue;
		lead = islead;
	}

	public String takeOutTheWord(String regex, String replacement) {
		char c1, c2;
		String nou;

		for (int i = 0; i < replacement.length(); i++) {
			c1 = replacement.charAt(i);
			nou="";
			for (int j = 0; j < regex.length(); j++) {
				c2 = regex.charAt(j);
				if (c1 == c2) 
					for(int k=j+1;k<regex.length();k++){//punem restul de regex(de dupa caracterul gasit) in nou
						nou=nou+regex.charAt(k);
						j=10;
				}
				else{nou=nou+c2;
				}
					
			}
			regex=nou;
		}
			
			return regex;
		}
		



	

	public static String getKLetters(int k) { // returneaza k litere aleatoare
		magicBag bag = new magicBag();
		String tiles = "";
		tiles = bag.getRandomLetters(k);
		return tiles;
	}

	public static String helpMe(String tiles) {
		help ajutor = new help();
		String GodWord;
		GodWord = ajutor.SearchBestWord(tiles);
		return GodWord;
	}

	public static void main(String[] args) {
		String letters = "";
		WordChecker verif = new WordChecker();
		String word = "";
		System.out.println(verif.check_for_word(word));
		System.out.println("\n");
		System.out.println(letters);
		System.out.println("\n");
		System.out.println(word);

	}

}
