package wordGame;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class server {
	
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in); 
		System.out.println("introduceti nr de threduri");
		int threadCount = reader.nextInt();;
		System.out.println("Spawing threads....");
		ArrayList<Thread> threads = new ArrayList<Thread>();
		for (int i = 0; i < threadCount; i++) {
			if (!((i + 1) == threadCount)) {
				threads.add(new Thread(new jocRun(i, false)));
			} else {
				threads.add(new Thread(new jocRun(i, true)));
			}
		}	
		for(int i=0;i< threads.size();i++)
		{
			threads.get(i).start();
		}
		
		
		
	}
}
