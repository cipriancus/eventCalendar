package wordGame;

import java.util.Random;

public class magicBag {

	String[] letters = { "e", "e", "e", "e", "e", "e", "e", "e", "e", "e", "e", "e", // 12
			"t", "t", "t", "t", "t", "t", "t", "t", "t", // 9
			"a", "a", "a", "a", "a", "a", "a", "a", // 8
			"o", "o", "o", "o", "o", "o", "o", // 7*3
			"i", "i", "i", "i", "i", "i", "i", "n", "n", "n", "n", "n", "n", "n", "s", "s", "s", "s", "s", "s", // 6*2
			"r", "r", "r", "r", "r", "r", "h", "h", "h", "h", "h", // 5
			"d", "d", "d", "d", // 4*2
			"l", "l", "l", "l", "u", "u", "u", // 3
			"c", "c", // 2*8
			"m", "m", "f", "f", "y", "y", "w", "w", "g", "g", "p", "p", "b", "b", "v", "k", "x", "q", "j", "z",// 1*6

	};
	private String allLetters = "eeeeeeeeeeeetttttttttaaaaaaaaoooooooiiiiiiinnnnnnnssssssrrrrrrhhhhhddddlllluuuccmmffyywwggppbbvkxqjz";

	public int letterCount() {
		return allLetters.length();
	}

	public String getRandomLetters(int k) {
		Random generator = new Random();
		String tiles = "";
		int randomInt;
		for (int i = 1; i <= k ; i++) {
			do {
				randomInt = generator.nextInt(allLetters.length());
			} while (randomInt < 0 && randomInt >= allLetters.length());
			tiles += allLetters.charAt(randomInt);
			allLetters = removeElement(randomInt);

		}
		return tiles;
	}

	public String removeElement(int indexul) {

		String newLetters = "";
		for (int i = 0; i < indexul; i++) {
			newLetters += allLetters.charAt(i);
		}

		for (int i = indexul + 1; i < allLetters.length(); i++) {
			newLetters += allLetters.charAt(i);
		}
		return newLetters;
	}

}
