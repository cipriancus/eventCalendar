package wordGame;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class WordChecker {
    public static boolean check_for_word(String word) {
        String str;
    	try {
    		str="";
            BufferedReader in = new BufferedReader(new FileReader("dictionar.txt"));
            while ((str = in.readLine()) != null) {
            	str = str.toLowerCase();
            	if(str.charAt(0)==word.charAt(0))//check first letter
            	{	
            		if(word.equals(str)){
            		return true;
            		}
            	}
            }
            in.close();
        } catch (IOException e) {
        }

        return false;
    }

}